package be.intecbrussel.the_notebook.plant_entities;

public enum Scent {

    SWEET,
    ORANGE,
    PINEAPPLE,
    MUSKY,
    EARTHY,
    SOUR;
}


