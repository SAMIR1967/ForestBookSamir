package be.intecbrussel.the_notebook.plant_entities;



	
	public enum Leaftype {

	    NEEDLE,
	    ROUND,
	    HAND,
	    HEART,
	    SPEAR;
	}

