package entities.plant_entities;

public class Plant {

}
